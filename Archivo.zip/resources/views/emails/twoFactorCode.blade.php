<!DOCTYPE html>
<html>
<head>
    <title>Two Factor Authentication Code</title>
</head>
<body>
    <p>Su código de verificación es: {{ $code }}</p>
</body>
</html>
