<?php

return [
    'app_front_url' => env('VITE_APP_FRONT_URL',  'http://localhost:3000'),
    'app_back_url' => env('VITE_APP_BACK_URL',  'http://localhost:8000'),
];
